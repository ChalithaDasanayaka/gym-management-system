/*package com.gym.utils;

public class DBTest {
    public static void main(String[] args) {
        DBConnection.getConnection();
        DBConnection.closeConnection();
    }
}*/
